import 'package:flutter/material.dart';
import 'package:gestion_gastos/screens/bottom_nav.dart';
import 'package:gestion_gastos/screens/dashboard_screen.dart';
// import 'package:gestion_gastos/screens/reports_screen.dart'; // Ya no es necesario importar ReportsScreen

const String appTitle = 'Gestión de Gastos';

void main() {
  runApp(const ExpenseTrackerApp());
}

class ExpenseTrackerApp extends StatelessWidget {
  const ExpenseTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2EB38E)),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const MainNavigator(),
    );
  }
}

class MainNavigator extends StatefulWidget {
  const MainNavigator({super.key});

  @override
  State<MainNavigator> createState() => _MainNavigatorState();
}

class _MainNavigatorState extends State<MainNavigator> {
  int _selectedIndex = 2;

  final List<Widget> _screens = [
    // 0: Mi Agenda
    const Center(child: Text('Pantalla 0 - Mi Agenda')), 
    
    // 1: Mis Notas (CAMBIO: Sustituimos ReportsScreen por un placeholder)
    const Center(child: Text('Pantalla 1 - Mis Notas (Sin Gráficas)')), 
    
    // 2: Mis Gastos (DashboardScreen)
    const DashboardScreen(), 
    
    // 3: Mis Hábitos
    const Center(child: Text('Pantalla 3 - Mis Hábitos')), 
  ];

  void _onItemTapped(int index) {
    if (_selectedIndex != index) {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentScreen = _screens.elementAt(_selectedIndex);

    return Scaffold(
      extendBody: true, 
      body: currentScreen,
      bottomNavigationBar: AnimatedNavBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}