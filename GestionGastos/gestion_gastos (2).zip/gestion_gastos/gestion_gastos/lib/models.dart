import 'package:flutter/material.dart';

// --- DEFINICIÓN DE CLASES Y ENUMS (MODELOS DE DATOS) ---

// 1. Enumeración para las categorías de gastos
enum Category {
  comida(Icons.fastfood, Color(0xFFF44336)), // Rojo
  transporte(Icons.directions_bus, Color(0xFF2196F3)), // Azul
  ocio(Icons.movie_filter, Color(0xFFFF9800)), // Naranja
  vivienda(Icons.house, Color(0xFF4CAF50)), // Verde
  servicios(Icons.electrical_services, Color(0xFF9C27B0)), // Púrpura
  otros(Icons.more_horiz, Color(0xFF607D8B)); // Gris-Azul

  // Propiedades para cada categoría
  final IconData icon;
  final Color color;

  // Constructor
  const Category(this.icon, this.color);
}

// 2. Modelo de datos para un Gasto (Expense)
class Expense {
  final String id;
  final String title;
  final double amount;
  final DateTime date;
  final Category category;

  Expense({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
  });
}

// 3. Modelo de datos para un Ingreso (Income)
// Para el reporte, solo necesitamos el monto y una descripción o fuente.
class Income {
  final String id;
  final String source; // Fuente del ingreso (Salario, Inversión, etc.)
  final double amount;
  final DateTime date;

  Income({
    required this.id,
    required this.source,
    required this.amount,
    required this.date,
  });
}

// --- DATOS DE PRUEBA (MOCK DATA) ---
// Usaremos estos datos para renderizar la pantalla inicial antes de implementar la base de datos.

// Lista de gastos de prueba
final List<Expense> mockExpenses = [
  Expense(
    id: 'e1',
    title: 'Viaje en metro',
    amount: 15.50,
    date: DateTime.now().subtract(const Duration(days: 1)),
    category: Category.transporte,
  ),
  Expense(
    id: 'e2',
    title: 'Cena con amigos',
    amount: 350.75,
    date: DateTime.now().subtract(const Duration(days: 2)),
    category: Category.comida,
  ),
  Expense(
    id: 'e3',
    title: 'Entrada al cine',
    amount: 180.00,
    date: DateTime.now().subtract(const Duration(days: 5)),
    category: Category.ocio,
  ),
  Expense(
    id: 'e4',
    title: 'Pago de renta',
    amount: 8000.00,
    date: DateTime.now().subtract(const Duration(days: 10)),
    category: Category.vivienda,
  ),
  Expense(
    id: 'e5',
    title: 'Recibo de luz',
    amount: 550.00,
    date: DateTime.now().subtract(const Duration(days: 15)),
    category: Category.servicios,
  ),
];

// Lista de ingresos de prueba
final List<Income> mockIncomes = [
  Income(
    id: 'i1',
    source: 'Salario',
    amount: 15000.00,
    date: DateTime.now().subtract(const Duration(days: 12)),
  ),
  Income(
    id: 'i2',
    source: 'Trabajo Freelance',
    amount: 5000.00,
    date: DateTime.now().subtract(const Duration(days: 3)),
  ),
];