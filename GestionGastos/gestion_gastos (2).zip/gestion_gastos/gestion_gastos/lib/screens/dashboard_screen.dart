import 'package:flutter/material.dart';
import 'package:gestion_gastos/models.dart';
import 'package:gestion_gastos/screens/reports_screen.dart';
import 'package:gestion_gastos/screens/add_income_screen.dart';
import 'package:gestion_gastos/screens/add_expense_screen.dart';

// 1. Cambiamos a StatefulWidget para poder guardar el cambio de la meta
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // Variable para guardar la meta del mes. Inicialmente en 500.
  double _monthlyGoal = 500.0;

  double _calculateBalance() {
    final totalIncomes =
        mockIncomes.fold(0.0, (sum, item) => sum + item.amount);
    final totalExpenses =
        mockExpenses.fold(0.0, (sum, item) => sum + item.amount);
    return totalIncomes - totalExpenses;
  }

  // --- Función para editar la Meta ---
  void _showEditGoalDialog() {
    TextEditingController goalController =
        TextEditingController(text: _monthlyGoal.toStringAsFixed(0));

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Editar Meta del Mes"),
          content: TextField(
            controller: goalController,
            keyboardType: TextInputType.number, // Teclado numérico
            decoration: const InputDecoration(
              prefixText: "\$ ",
              border: OutlineInputBorder(),
              labelText: "Nueva cantidad",
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancelar"),
            ),
            ElevatedButton(
              onPressed: () {
                // Actualizamos el estado con el nuevo valor
                setState(() {
                  _monthlyGoal =
                      double.tryParse(goalController.text) ?? _monthlyGoal;
                });
                Navigator.pop(context); // Cerrar el diálogo
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF37A078),
                foregroundColor: Colors.white,
              ),
              child: const Text("Guardar"),
            ),
          ],
        );
      },
    );
  }

  // --- Botones inferiores (Ingreso, Gasto, Reporte) ---
  Widget _buildActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    const iconBgColor = Color(0xFF457B6B);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15.0),
      child: Container(
        width: 100,
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        decoration: BoxDecoration(
          color: iconBgColor,
          borderRadius: BorderRadius.circular(15.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white, size: 36),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentBalance = _calculateBalance();

    return Scaffold(
      // --- ENCABEZADO ---
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: Container(
          padding: const EdgeInsets.only(top: 25, left: 16, right: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 6,
                  offset: const Offset(0, 3))
            ],
          ),
          child: Row(
            children: [
              // Ícono dentro de un contenedor redondeado verde
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: const Color(0xFF37A078),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.attach_money,
                    color: Colors.white, size: 26),
              ),

              const SizedBox(width: 12),

              const Text(
                "Gestión de Gastos",
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87),
              ),

              const Spacer(),

              // MENÚ DESPLEGABLE CON FONDO CIRCULAR (Como tu imagen)
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200, // Fondo gris claro circular
                  shape: BoxShape.circle,
                ),
                child: PopupMenuButton<String>(
                  icon: const Icon(Icons.menu, color: Colors.black87, size: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  onSelected: (String value) {
                    if (value == 'ingresos') {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AddIncomeScreen()));
                    } else if (value == 'egresos') {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AddExpenseScreen()));
                    } else if (value == 'grafica') {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ReportsScreen()));
                    }
                  },
                  itemBuilder: (BuildContext context) =>
                      <PopupMenuEntry<String>>[
                    const PopupMenuItem<String>(
                      value: 'ingresos',
                      child: Row(children: [
                        Icon(Icons.arrow_upward, color: Color(0xFF37A078)),
                        SizedBox(width: 10),
                        Text('Ingresos')
                      ]),
                    ),
                    const PopupMenuItem<String>(
                      value: 'egresos',
                      child: Row(children: [
                        Icon(Icons.arrow_downward, color: Colors.redAccent),
                        SizedBox(width: 10),
                        Text('Egresos')
                      ]),
                    ),
                    const PopupMenuDivider(),
                    const PopupMenuItem<String>(
                      value: 'grafica',
                      child: Row(children: [
                        Icon(Icons.bar_chart, color: Colors.blueAccent),
                        SizedBox(width: 10),
                        Text('Gráfica')
                      ]),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // --- CUERPO ---
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Saldo
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                      color: Theme.of(context).colorScheme.primary, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.4),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    )
                  ],
                ),
                child: Center(
                  child: Text(
                    '\$${currentBalance.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // 2. Meta del mes (AHORA EDITABLE)
              InkWell(
                onTap: _showEditGoalDialog, // Al tocar, abre el editor
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Theme.of(context).primaryColor.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text('Meta del mes',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w500)),
                          const SizedBox(width: 8),
                          // Icono de lápiz pequeño para indicar que se puede editar
                          Icon(Icons.edit,
                              size: 16, color: Colors.grey.shade600),
                        ],
                      ),
                      Text(
                        '\$${_monthlyGoal.toStringAsFixed(0)}', // Usamos la variable
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // 3. Gráfico (placeholder)
              Container(
                height: 150,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.grey.shade300)),
                child: Center(
                  child: Icon(Icons.bar_chart_rounded,
                      size: 80,
                      color: Theme.of(context).colorScheme.primary),
                ),
              ),

              const SizedBox(height: 30),

              // 4. Botones inferiores
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildActionButton(
                    context,
                    icon: Icons.arrow_upward,
                    label: 'Ingreso',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const AddIncomeScreen()),
                      );
                    },
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.arrow_downward,
                    label: 'Gasto',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const AddExpenseScreen()),
                      );
                    },
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.show_chart,
                    label: 'Reporte',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ReportsScreen()),
                      );
                    },
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}