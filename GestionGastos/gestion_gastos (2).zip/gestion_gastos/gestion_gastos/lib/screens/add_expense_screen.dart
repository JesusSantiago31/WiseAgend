import 'package:flutter/material.dart';

// --- CONSTANTES DE COLOR VERDE (Para todos los inputs ahora) ---
const Color _primaryGreen = Color(0xFF2EB38E);
const Color _lightGreen = Color(0xFF30D5A0);
// No se necesita _shadowColor si se usa _primaryGreen para la sombra.

// =========================================================================
// WIDGET AUXILIAR PARA EL ESTILO GLOW INPUT (VERDE)
// =========================================================================

/// Widget para crear un campo de texto con estilo Glow Input (Borde brillante).
/// Este widget ahora es genérico para ambos, ingresos y gastos (en verde).
class GlowInputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData? icon; 
  final TextInputType keyboardType;
  final bool isLargeInput; 

  const GlowInputField({
    super.key,
    required this.controller,
    required this.label,
    required this.hint,
    this.icon,
    this.keyboardType = TextInputType.text,
    this.isLargeInput = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 30), 
      height: isLargeInput ? 70 : 60, 
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          // Sombra de "Glow" en color VERDE
          BoxShadow(
            color: _primaryGreen.withOpacity(0.3), 
            blurRadius: 8,
            spreadRadius: 0,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        textAlign: isLargeInput ? TextAlign.center : TextAlign.start,
        style: TextStyle(
          // Monto en color verde principal
          color: isLargeInput ? _primaryGreen : Colors.black87,
          fontSize: isLargeInput ? 24 : 16,
          fontWeight: isLargeInput ? FontWeight.bold : FontWeight.normal,
        ),
        decoration: InputDecoration(
          isDense: true,
          contentPadding: EdgeInsets.symmetric(
            vertical: isLargeInput ? 20 : 18, 
            horizontal: 10,
          ),
          labelText: label,
          hintText: hint,
          fillColor: Colors.white, 
          filled: true,
          // BORDES Y DECORACIÓN DEL GLOW INPUT (VERDE)
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none, 
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _primaryGreen, width: 2), // Borde verde
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _lightGreen, width: 3), // Borde más brillante al enfocar
          ),
          // Prefijo para el Monto
          prefixIcon: isLargeInput
              ? Text('\$', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: _primaryGreen))
              : (icon != null ? Icon(icon, color: _primaryGreen) : null), // Icono normal para otros campos
          prefixIconConstraints: isLargeInput ? const BoxConstraints(minWidth: 40, minHeight: 0) : null,
          labelStyle: const TextStyle(color: Colors.black54),
        ),
      ),
    );
  }
}

// =========================================================================
// ADD EXPENSE SCREEN (PANTALLA PRINCIPAL)
// =========================================================================

class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  
  String? _selectedCategory;
  DateTime _selectedDate = DateTime.now();

  final List<String> _categories = [
    'Transporte', 
    'Comida', 
    'Ocio', 
    'Renta', 
    'Servicios',
    'Otros'
  ];

  final Color primaryColor = _primaryGreen; // Usamos el verde primario para la AppBar

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: primaryColor, 
              onPrimary: Colors.white, 
              onSurface: Colors.black, 
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _saveExpense() {
    final amount = double.tryParse(_amountController.text.replaceAll(',', '.')) ?? 0.0;
    final description = _descriptionController.text;
    
    if (amount <= 0 || description.isEmpty || _selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Por favor, completa todos los campos requeridos.'),
          backgroundColor: Colors.red, // Mantener el rojo para errores
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Gasto de \$${amount.toStringAsFixed(2)} guardado en $_selectedCategory.'),
        backgroundColor: _primaryGreen, // Mensaje de éxito en verde
      ),
    );

    _amountController.clear();
    _descriptionController.clear();
    setState(() {
      _selectedCategory = null;
      _selectedDate = DateTime.now();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF), 
      appBar: AppBar(
        title: const Text('Agregar Gasto'),
        backgroundColor: primaryColor, // AppBar verde
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(top: 30.0, left: 24.0, right: 24.0, bottom: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 1. CAMPO MONTO (Glow Input Verde)
            GlowInputField( // Usamos el widget GlowInputField genérico
              controller: _amountController,
              label: 'Monto del Gasto',
              hint: '0.00',
              icon: Icons.attach_money, 
              keyboardType: TextInputType.number,
              isLargeInput: true,
            ),
            
            // 2. DESCRIPCIÓN (Glow Input Verde)
            GlowInputField( // Usamos el widget GlowInputField genérico
              controller: _descriptionController,
              label: 'Descripción/Detalle',
              hint: 'Ej: Pago de Luz o Café con amigos',
              icon: Icons.notes_rounded,
              keyboardType: TextInputType.text,
            ),
            
            // 3. CATEGORÍA (Dropdown - con estilo Glow Input Verde)
            Container(
              margin: const EdgeInsets.only(bottom: 30), 
              height: 60, 
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: _primaryGreen.withOpacity(0.3), // Sombra verde
                    blurRadius: 8,
                    spreadRadius: 0,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: DropdownButtonFormField<String>(
                isDense: true,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 10),
                  labelText: 'Tipo de Gasto',
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _primaryGreen, width: 2), // Borde verde
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _lightGreen, width: 3), // Borde brillante verde
                  ),
                  prefixIcon: Icon(Icons.category, color: _primaryGreen),
                  labelStyle: const TextStyle(color: Colors.black54),
                ),
                value: _selectedCategory,
                hint: const Text('Selecciona una categoría', style: TextStyle(color: Colors.black54)),
                isExpanded: true,
                items: _categories.map((String category) {
                  return DropdownMenuItem<String>(
                    value: category,
                    child: Text(category, style: const TextStyle(color: Colors.black87)),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCategory = newValue;
                  });
                },
                icon: Icon(Icons.arrow_drop_down, color: _primaryGreen),
              ),
            ),

            // 4. FECHA (Selector - con estilo Glow Input Verde)
            Container(
              margin: const EdgeInsets.only(bottom: 40), 
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: _primaryGreen.withOpacity(0.3), // Sombra verde
                    blurRadius: 8,
                    spreadRadius: 0,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Material(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => _selectDate(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _primaryGreen, width: 2), // Borde verde
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today, color: _primaryGreen),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Fecha: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                            style: const TextStyle(fontSize: 16, color: Colors.black87),
                          ),
                        ),
                        Icon(Icons.keyboard_arrow_down, color: _primaryGreen),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            
            // 5. BOTÓN GUARDAR (Verde con Glow)
            Container(
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                boxShadow: [
                  BoxShadow(
                    color: _primaryGreen.withOpacity(0.5), // Sombra de glow verde
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
                gradient: const LinearGradient(
                  colors: [_lightGreen, _primaryGreen], // Gradiente verde
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
              child: ElevatedButton.icon(
                onPressed: _saveExpense,
                icon: const Icon(Icons.save, color: Colors.white),
                label: const Text(
                  'Guardar Gasto',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent, 
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}