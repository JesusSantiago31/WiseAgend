import 'package:flutter/material.dart';
import 'dart:math';

// --- Constantes de Diseño ---
const Color _primaryColor = Color(0xFF38765A); // Verde oscuro para AppBar
const Color _borderColor = Color(0xFF38765A); // Borde verde
const Color _backgroundColor = Colors.white;
const Color _categoryTextColor = Colors.black;

// Colores asignados a cada categoría para los gráficos
final Map<String, Color> _categoryColors = {
  'Transporte': const Color(0xFF4C98E5), // Azul
  'Comida': const Color(0xFFEE798D),    // Rojo/Rosa
  'Ocio': const Color(0xFF000000),      // Negro
  'Servicios': const Color(0xFF5BAA6D), // Verde
};

// Datos simulados (solo los valores totales para Barras y Pastel)
final Map<String, double> _categoryTotals = {
  'Transporte': 3000,
  'Comida': 2500,
  'Ocio': 1500,
  'Servicios': 2000,
};

// Datos detallados por punto para el gráfico de Línea (usado en _LineChartPainter)
final Map<String, List<double>> _lineData = {
  'Transporte': [100.0, 100.0, 200.0, 230.0, 230.0, 240.0, 300.0, 330.0, 200.0, 250.0, 220.0, 180.0, 150.0, 130.0],
  'Comida': [90.0, 110.0, 105.0, 115.0, 120.0, 140.0, 130.0, 250.0, 240.0, 280.0, 250.0, 290.0, 280.0, 300.0],
  'Ocio': [50.0, 80.0, 100.0, 110.0, 115.0, 130.0, 140.0, 150.0, 160.0, 180.0, 190.0, 200.0, 210.0, 220.0],
  'Servicios': [150.0, 130.0, 150.0, 170.0, 180.0, 200.0, 220.0, 210.0, 190.0, 170.0, 160.0, 180.0, 200.0, 230.0],
};


// --- Tipos de Gráfica ---
enum ChartType {
  linea,
  barras,
  pastel,
}

// --- CLASE PRINCIPAL: ReportsScreen (StatefulWidget) ---
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  ChartType _currentChartType = ChartType.linea;

  // Lista de categorías y su estado de selección
  final Map<String, bool> _categories = {
    'Transporte': true,
    'Comida': true,
    'Ocio': true,
    'Servicios': true,
  };

  void _changeChartType() {
    setState(() {
      final nextIndex = (_currentChartType.index + 1) % ChartType.values.length;
      _currentChartType = ChartType.values[nextIndex];
    });
  }

  String _getChartName() {
    switch (_currentChartType) {
      case ChartType.linea:
        return 'Línea';
      case ChartType.barras:
        return 'Barras';
      case ChartType.pastel:
        return 'Pastel';
    }
  }

  void _onCategoryToggled(String category, bool? isSelected) {
    if (isSelected != null) {
      setState(() {
        _categories[category] = isSelected;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Obtener solo las categorías activas
    final List<String> activeCategories = _categories.entries
        .where((e) => e.value)
        .map((e) => e.key)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Gestión del Mes',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: _primaryColor,
        foregroundColor: Colors.white,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {},
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // 1. Botón "Tipo de grafica"
              _CrownButton(
                text: 'Tipo de Gráfica: ${_getChartName()}',
                onPressed: _changeChartType,
              ),
              const SizedBox(height: 20),

              // 2. Área de la Gráfica (Depende del estado)
              _ChartAreaPlaceholder(
                chartType: _currentChartType,
                activeCategories: activeCategories,
              ),
              const SizedBox(height: 20),

              // 3. Texto "Categorias" con el marco
              const _SectionTitle(title: 'Categorias'),
              const SizedBox(height: 20),

              // 4. Lista de Categorías (Interactiva)
              _CategoryList(
                categories: _categories,
                onToggle: _onCategoryToggled,
              ),
              const SizedBox(height: 50),

              // 5. Botón "Descargar Reporte"
              _CrownButton(
                text: 'Descargar Reporte',
                onPressed: () {},
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

// --- WIDGETS DE COMPONENTES ---

// Widget para simular la gráfica compleja, ahora reacciona al estado
class _ChartAreaPlaceholder extends StatelessWidget {
  final ChartType chartType;
  final List<String> activeCategories;

  const _ChartAreaPlaceholder({
    required this.chartType,
    required this.activeCategories,
  });

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.5,
      child: Container(
        decoration: BoxDecoration(
          color: _backgroundColor,
          border: Border.all(color: Colors.grey.shade300),
        ),
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: _getChartWidget(),
        ),
      ),
    );
  }

  Widget _getChartWidget() {
    if (activeCategories.isEmpty) {
      return Text(
        'Selecciona al menos una categoría\npara ver el gráfico de ${_getChartName()}',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.grey.shade500, fontSize: 16),
      );
    }
    
    switch (chartType) {
      case ChartType.linea:
        return CustomPaint(
          painter: _LineChartPainter(activeCategories: activeCategories),
          child: Container(),
        );
      case ChartType.barras:
        return CustomPaint(
          painter: _BarChartPainter(activeCategories: activeCategories),
          child: Container(),
        );
      case ChartType.pastel:
        return CustomPaint(
          painter: _PieChartPainter(activeCategories: activeCategories),
          child: Container(),
        );
    }
  }

  String _getChartName() {
    switch (chartType) {
      case ChartType.linea: return 'Línea';
      case ChartType.barras: return 'Barras';
      case ChartType.pastel: return 'Pastel';
    }
  }
}

// --- CUSTOM PAINTERS ---

// Gráfico 1: Línea (implementación ya existente)
class _LineChartPainter extends CustomPainter {
  final List<String> activeCategories;

  _LineChartPainter({required this.activeCategories});

  @override
  void paint(Canvas canvas, Size size) {
    const double maxValue = 350.0;
    final scaleFactor = size.height / maxValue;
    const dataPointsCount = 14;
    final xStep = size.width / (dataPointsCount - 1);
    const pointRadius = 3.0;

    double getY(double dataValue) => size.height - (dataValue * scaleFactor);

    // Ejes (simplificados)
    final linePaint = Paint()..color = Colors.grey.shade400..strokeWidth = 1.0..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(0, size.height), Offset(size.width, size.height), linePaint);

    void drawChartLine(String category) {
      final List<double> data = _lineData[category]!;
      final Color color = _categoryColors[category]!;
      
      final linePath = Path();
      final linePaint = Paint()..color = color..strokeWidth = 2.0..style = PaintingStyle.stroke;

      linePath.moveTo(0, getY(data[0]));
      for (int i = 1; i < data.length; i++) {
        linePath.lineTo(i * xStep, getY(data[i]));
      }
      canvas.drawPath(linePath, linePaint);

      final pointPaint = Paint()..color = color..style = PaintingStyle.fill;
      for (int i = 0; i < data.length; i++) {
        canvas.drawCircle(Offset(i * xStep, getY(data[i])), pointRadius, pointPaint);
        canvas.drawCircle(Offset(i * xStep, getY(data[i])), pointRadius, Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 1.0);
      }
    }

    _categoryColors.keys.where((c) => activeCategories.contains(c)).forEach(drawChartLine);
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter oldDelegate) {
    return oldDelegate.activeCategories.length != activeCategories.length ||
        oldDelegate.activeCategories.any((cat) => !activeCategories.contains(cat));
  }
}

// Gráfico 2: Barras (Nueva Implementación)
class _BarChartPainter extends CustomPainter {
  final List<String> activeCategories;

  _BarChartPainter({required this.activeCategories});

  @override
  void paint(Canvas canvas, Size size) {
    final double maxTotal = _categoryTotals.values.reduce(max);
    final double barWidth = 30.0;
    final double spacing = (size.width - (activeCategories.length * barWidth)) / (activeCategories.length + 1);
    double currentX = spacing;

    for (var category in activeCategories) {
      final double total = _categoryTotals[category]!;
      final Color color = _categoryColors[category]!;
      final double barHeight = (total / maxTotal) * (size.height - 20); // -20 para padding visual

      final rect = Rect.fromLTWH(
        currentX,
        size.height - barHeight,
        barWidth,
        barHeight,
      );

      final paint = Paint()
        ..color = color
        ..style = PaintingStyle.fill;

      canvas.drawRect(rect, paint);
      
      // Añadir etiqueta de categoría (opcional)
      final textPainter = TextPainter(
        text: TextSpan(text: category[0], style: TextStyle(color: Colors.white, fontSize: 10)),
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();
      textPainter.paint(canvas, Offset(currentX + (barWidth / 2) - (textPainter.width / 2), size.height - barHeight + 5));
      
      currentX += barWidth + spacing;
    }
  }

  @override
  bool shouldRepaint(covariant _BarChartPainter oldDelegate) {
    return oldDelegate.activeCategories.length != activeCategories.length ||
        oldDelegate.activeCategories.any((cat) => !activeCategories.contains(cat));
  }
}

// Gráfico 3: Pastel (Nueva Implementación)
class _PieChartPainter extends CustomPainter {
  final List<String> activeCategories;

  _PieChartPainter({required this.activeCategories});

  @override
  void paint(Canvas canvas, Size size) {
    final activeData = activeCategories.map((c) => _categoryTotals[c]!).toList();
    final totalSum = activeData.isEmpty ? 0 : activeData.reduce((a, b) => a + b);

    if (totalSum == 0) return;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2 - 10;
    Rect rect = Rect.fromCircle(center: center, radius: radius);

    double startAngle = -pi / 2; // Iniciar desde arriba

    for (var category in activeCategories) {
      final double value = _categoryTotals[category]!;
      final Color color = _categoryColors[category]!;

      final sweepAngle = (value / totalSum) * 2 * pi;

      final paint = Paint()
        ..color = color
        ..style = PaintingStyle.fill;

      canvas.drawArc(rect, startAngle, sweepAngle, true, paint);
      
      // Dibujar borde blanco entre secciones (opcional)
      final borderPaint = Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.0;
      canvas.drawArc(rect, startAngle, sweepAngle, true, borderPaint);

      startAngle += sweepAngle;
    }
  }

  @override
  bool shouldRepaint(covariant _PieChartPainter oldDelegate) {
    return oldDelegate.activeCategories.length != activeCategories.length ||
        oldDelegate.activeCategories.any((cat) => !activeCategories.contains(cat));
  }
}

// --- WIDGETS DE COMPONENTES (sin cambios) ---

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: _borderColor, width: 2.0),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: _categoryTextColor,
        ),
      ),
    );
  }
}

class _CrownButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;

  const _CrownButton({required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: _categoryTextColor,
        side: const BorderSide(color: _borderColor, width: 2.0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            text,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: _categoryTextColor,
            ),
          ),
          const SizedBox(width: 8),
          const Icon(
            Icons.public,
            color: _borderColor,
            size: 20,
          ),
        ],
      ),
    );
  }
}

class _CategoryList extends StatelessWidget {
  final Map<String, bool> categories;
  final Function(String, bool?) onToggle;

  const _CategoryList({required this.categories, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: categories.entries.map((entry) {
        return _CategoryItem(
          text: entry.key,
          isSelected: entry.value,
          onToggle: (isSelected) => onToggle(entry.key, isSelected),
        );
      }).toList(),
    );
  }
}

class _CategoryItem extends StatelessWidget {
  final String text;
  final bool isSelected;
  final Function(bool?) onToggle;

  const _CategoryItem({
    required this.text,
    required this.isSelected,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          InkWell(
            onTap: () => onToggle(!isSelected),
            child: Row(
              children: [
                Icon(
                  isSelected ? Icons.check_box : Icons.check_box_outline_blank,
                  color: isSelected ? Colors.black : Colors.grey,
                  size: 30,
                ),
                const SizedBox(width: 10),
                Text(
                  text,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w600,
                    color: _categoryTextColor,
                    height: 1.0,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}