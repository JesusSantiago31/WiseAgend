import 'package:flutter/material.dart';
import 'dart:ui'; // Necesario para el BackdropFilter (Glassmorphism)

// =========================================================================
// WIDGETS AUXILIARES PARA EL ESTILO VISUAL
// =========================================================================

// Color Verde Principal utilizado en la aplicación
const Color _primaryGreen = Color(0xFF2EB38E);
const Color _lightGreen = Color(0xFF30D5A0);
const Color _shadowColor = _primaryGreen;

/// Widget para crear un campo de texto con estilo Glass Input.
class GlassInputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final TextInputType keyboardType;

  const GlassInputField({
    super.key,
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.keyboardType = TextInputType.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 25), // ⭐ Aumento de margen (espacio)
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: _shadowColor.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Container(
            // ⭐ Altura ajustada si el contenido es pequeño
            height: 60, 
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.25), // Aumento de opacidad del fondo
              borderRadius: BorderRadius.circular(15),
              // ⭐ BORDE TRANSPARENTE VISIBLE
              border: Border.all(
                color: Colors.white.withOpacity(0.5), // Borde más opaco para que se note
                width: 1.5,
              ),
              gradient: LinearGradient(
                colors: [
                  _lightGreen.withOpacity(0.2),
                  _primaryGreen.withOpacity(0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            // ⭐ Alineación centrada para los campos
            alignment: Alignment.center,
            child: TextFormField(
              controller: controller,
              keyboardType: keyboardType,
              style: const TextStyle(color: Colors.black87),
              decoration: InputDecoration(
                labelText: label,
                hintText: hint,
                border: InputBorder.none, // Quitamos el borde nativo
                prefixIcon: Icon(icon, color: _primaryGreen),
                labelStyle: const TextStyle(color: Colors.black54),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Widget para crear un campo de texto con estilo Glow Input (Borde brillante).
class GlowInputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final TextInputType keyboardType;

  const GlowInputField({
    super.key,
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.keyboardType = TextInputType.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 25), // ⭐ Aumento de margen (espacio)
      height: 60, // ⭐ Altura ajustada
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: _primaryGreen.withOpacity(0.3), 
            blurRadius: 8,
            spreadRadius: 0,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(color: Colors.black87),
        decoration: InputDecoration(
          // Centrado vertical del texto de entrada
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 10),
          labelText: label,
          hintText: hint,
          fillColor: Colors.white, 
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none, 
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _primaryGreen, width: 2), // Borde verde
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _lightGreen, width: 3),
          ),
          prefixIcon: Icon(icon, color: _primaryGreen),
          labelStyle: const TextStyle(color: Colors.black54),
        ),
      ),
    );
  }
}

// =========================================================================
// ADD INCOME SCREEN (PANTALLA PRINCIPAL)
// =========================================================================

class AddIncomeScreen extends StatefulWidget {
  const AddIncomeScreen({super.key});

  @override
  State<AddIncomeScreen> createState() => _AddIncomeScreenState();
}

class _AddIncomeScreenState extends State<AddIncomeScreen> {
  // Controladores para los campos de texto
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  
  // Variables de estado
  String? _selectedCategory;
  DateTime _selectedDate = DateTime.now();

  // Opciones de categoría de ejemplo para Ingresos
  final List<String> _categories = [
    'Salario', 
    'Inversiones', 
    'Trabajo Freelance', 
    'Ventas', 
    'Regalo',
    'Otros'
  ];

  // Colores de la aplicación (Verde Principal para el tema)
  final Color primaryColor = _primaryGreen; 

  // Función para mostrar el selector de fecha
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: primaryColor, 
              onPrimary: Colors.white, 
              onSurface: Colors.black, 
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  // Función para simular el guardado del Ingreso
  void _saveIncome() {
    final amount = double.tryParse(_amountController.text.replaceAll(',', '.')) ?? 0.0;
    final description = _descriptionController.text;
    
    if (amount <= 0 || description.isEmpty || _selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Por favor, completa todos los campos requeridos.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Ingreso de \$${amount.toStringAsFixed(2)} guardado como $_selectedCategory.'),
        backgroundColor: Colors.green,
      ),
    );

    _amountController.clear();
    _descriptionController.clear();
    setState(() {
      _selectedCategory = null;
      _selectedDate = DateTime.now();
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF), 
      appBar: AppBar(
        title: const Text('Agregar Ingreso'),
        backgroundColor: primaryColor, 
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 1. CAMPO MONTO (Glow Input - altura y margen ajustados)
            GlowInputField(
              controller: _amountController,
              label: 'Monto del Ingreso',
              hint: '100.00',
              icon: Icons.attach_money,
              keyboardType: TextInputType.number,
            ),
            
            // 2. DESCRIPCIÓN / FUENTE (Glass Input - borde más visible)
            GlassInputField(
              controller: _descriptionController,
              label: 'Fuente/Descripción',
              hint: 'Ej: Salario Mensual o Pago de Cliente X',
              icon: Icons.notes_rounded,
              keyboardType: TextInputType.text,
            ),
            
            // 3. CATEGORÍA (Dropdown - aplicado el estilo Glassmorphism con borde visible)
            Container(
              margin: const EdgeInsets.only(bottom: 25), // ⭐ Aumento de margen
              height: 60, // ⭐ Altura ajustada
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: _shadowColor.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(15),
                      // ⭐ BORDE TRANSPARENTE VISIBLE
                      border: Border.all(
                        color: Colors.white.withOpacity(0.5), 
                        width: 1.5,
                      ),
                      gradient: LinearGradient(
                        colors: [
                          _lightGreen.withOpacity(0.2),
                          _primaryGreen.withOpacity(0.05),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    alignment: Alignment.center,
                    child: DropdownButtonFormField<String>(
                      // Ajustes para centrado vertical y alineación
                      isDense: true,
                      decoration: InputDecoration(
                        labelText: 'Tipo de Ingreso',
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.category, color: _primaryGreen),
                        labelStyle: const TextStyle(color: Colors.black54),
                      ),
                      value: _selectedCategory,
                      hint: const Text('Selecciona el tipo de ingreso', style: TextStyle(color: Colors.black54)),
                      isExpanded: true,
                      // Quitamos el underline nativo del Dropdown
                      items: _categories.map((String category) {
                        return DropdownMenuItem<String>(
                          value: category,
                          child: Text(category, style: const TextStyle(color: Colors.black87)),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedCategory = newValue;
                        });
                      },
                    ),
                  ),
                ),
              ),
            ),

            // 4. FECHA (ListTile - aplicado el estilo Glassmorphism con borde visible)
            Container(
              margin: const EdgeInsets.only(bottom: 40),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: _shadowColor.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(15),
                      // ⭐ BORDE TRANSPARENTE VISIBLE
                      border: Border.all(
                        color: Colors.white.withOpacity(0.5),
                        width: 1.5,
                      ),
                      gradient: LinearGradient(
                        colors: [
                          _lightGreen.withOpacity(0.2),
                          _primaryGreen.withOpacity(0.05),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: ListTile(
                      // Usamos padding vertical para que el ListTile no sea demasiado alto
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 2.0),
                      leading: Icon(Icons.calendar_today, color: _primaryGreen),
                      title: Text(
                        'Fecha: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                        style: const TextStyle(fontSize: 16, color: Colors.black87),
                      ),
                      trailing: const Icon(Icons.keyboard_arrow_down, color: Colors.black54),
                      onTap: () => _selectDate(context),
                    ),
                  ),
                ),
              ),
            ),
            
            // 5. BOTÓN GUARDAR
            Container(
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                boxShadow: [
                  BoxShadow(
                    color: _primaryGreen.withOpacity(0.5), 
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
                gradient: const LinearGradient(
                  colors: [_lightGreen, _primaryGreen], 
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
              child: ElevatedButton.icon(
                onPressed: _saveIncome,
                icon: const Icon(Icons.save, color: Colors.white),
                label: const Text(
                  'Guardar Ingreso',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent, 
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}